import styled from 'styled-components'
import {dash, rotate} from './SpinnerAnimations'

export const StyledCircle = styled.circle`
    stroke-dasharray: 33,200;
    stroke-dashoffset: 0;
    animation: ${dash} 1.5s ease-in-out infinite;
    stroke-linecap: round;
`

export const StyledSpinner = styled.svg`
  animation: ${rotate} 2s linear infinite;
  position: absolute;
  height:120px;
  width:250px;
  padding: 0 65px 0 65px;
`
export const StyledLotus = styled.svg`
    width:250px;
    height:120px;
    padding: 36px;
`

export const SpinnerWrapper = styled.div`
    display: inline-block;
    max-width: 250px;
    max-height: 200px;
`

export const LoaderText = styled.p`
    text-align: center;
    color: ${props => props.type === 'light' ? '#FFFFFF' : '#494949'};
    font-size: 32px;
    font-weight: 300;
    letter-spacing: -0.32px;
    line-height: 35px;
    width:250px;
`
