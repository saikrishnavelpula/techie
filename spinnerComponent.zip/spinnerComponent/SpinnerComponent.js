import React from 'react'
import PropTypes from 'prop-types'
import {StyledSpinner, StyledCircle, SpinnerWrapper, StyledLotus, LoaderText} from './SpinnerStyledComponents'

const Spinner = (props) => (
  <SpinnerWrapper>
    <StyledSpinner viewBox='25 25 50 50'>
      <StyledCircle className='path' cx='50' cy='50' r='20' fill='none' strokeWidth='2' strokeMiterlimit='10' stroke={'#00c6d7'} />
    </StyledSpinner>
    <StyledLotus viewBox='0 0 16 16' >
      <path
        d='M8 4.916c.709 0 1.507.607 1.508 1.445 0 .471-.152.835-.374 1.164a2.18 2.18 0 0 0-.298.636c-.048.202-.155.685.442.696.386.007 1.34-.326 2.11-1.249A4.334 4.334 0 0 0 7.999.571 4.335 4.335 0 0 0 4.61 7.608c.77.923 1.724 1.256 2.11 1.249.598-.011.491-.493.443-.695a2.18 2.18 0 0 0-.298-.636c-.22-.33-.373-.694-.373-1.164.001-.839.8-1.446 1.508-1.446zm7.664 4.381c-.177-.146-.49-.36-1.128-.455-.886-.134-1.679.074-2.157.263-.625.246-1.399.803-1.932 1.534-.562.77-.856 1.933-.575 3.145.08.344.165.534.29.772.171.326.607.778.992.86.306.064.544-.112.658-.242.775-.891 3.712-4.34 4.03-4.783.314-.436.11-.855-.178-1.094M3.621 9.104c-.477-.189-1.271-.397-2.157-.263-.638.096-.951.31-1.128.455-.288.239-.493.659-.179 1.094.318.442 3.254 3.891 4.03 4.783.114.131.352.307.657.242.386-.082.822-.534.993-.86a2.9 2.9 0 0 0 .29-.772c.281-1.212-.013-2.375-.575-3.145-.532-.731-1.305-1.288-1.931-1.534'
        fill={props.type === 'light' ? '#FFFFFF' : '#0C7DBA'}
      />
    </StyledLotus>
    <LoaderText type={props.type}>{props.message}</LoaderText>
  </SpinnerWrapper>
)

Spinner.propTypes = {
  type: PropTypes.oneOf(['light', 'dark']),
  message: PropTypes.string
}
Spinner.defaultProps = {
  type: 'light'
}
export default Spinner
