'use strict'
angular.module("britishGas",["ui.router"]);